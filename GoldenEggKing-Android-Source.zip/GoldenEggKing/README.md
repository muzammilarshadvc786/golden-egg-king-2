# Golden Egg King — Android starter app

A Kotlin + Jetpack Compose Android Studio project for the Golden Egg King demo UI.

## Included
- Welcome screen
- Mobile-number/password login screen
- Sign-up screen
- Mock OTP verification screen (accepts any input; no SMS is sent)
- Dashboard with sample package cards, demo wallet, egg records, referrals and profile menu placeholders

## Important
This is a UI prototype only. It has no backend, real authentication, SMS OTP, payment processing, withdrawals, or real egg/reward accounting. Do not collect real user credentials or money with this demo. Before launch, connect a secure backend, SMS provider, database, and compliant payment provider; define and verify the real business model and reward rules.

## Build
Open this folder in Android Studio (Hedgehog or newer), allow Gradle sync, then select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
