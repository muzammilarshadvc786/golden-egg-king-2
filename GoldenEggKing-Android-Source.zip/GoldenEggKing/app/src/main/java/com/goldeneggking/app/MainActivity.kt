package com.goldeneggking.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Forest = Color(0xFF073B2A)
private val Green = Color(0xFF126344)
private val Gold = Color(0xFFFFD166)
private val Cream = Color(0xFFFFF8E7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GoldenEggKingApp() }
    }
}

@Composable
fun GoldenEggKingApp() {
    var page by remember { mutableStateOf("welcome") }
    var phone by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    MaterialTheme {
        Surface(Modifier.fillMaxSize(), color = Forest) {
            when (page) {
                "welcome" -> WelcomeScreen({ page = "login" }, { page = "signup" })
                "login" -> AuthScreen("LOGIN", phone, { phone = it }, password, { password = it }, { page = "home" }, { page = "signup" })
                "signup" -> SignupScreen(name, { name = it }, phone, { phone = it }, password, { password = it }, { page = "otp" }, { page = "login" })
                "otp" -> OtpScreen({ page = "home" })
                else -> HomeScreen({ page = "welcome" })
            }
        }
    }
}

@Composable
fun BrandHeader() {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        Text("👑", fontSize = 58.sp)
        Text("GOLDEN EGG KING", color = Gold, fontSize = 27.sp, fontWeight = FontWeight.Black)
        Text("ROYAL FARM • DEMO APP", color = Cream.copy(alpha = .8f), fontSize = 11.sp, letterSpacing = 2.sp)
    }
}

@Composable
fun WelcomeScreen(login: () -> Unit, signup: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        BrandHeader(); Spacer(Modifier.height(42.dp))
        Text("خوش آمدید", color = Cream, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Your royal egg farm dashboard", color = Cream.copy(alpha = .8f))
        Spacer(Modifier.height(30.dp))
        GoldButton("LOGIN", login); Spacer(Modifier.height(12.dp)); OutlineButton("CREATE ACCOUNT", signup)
        Spacer(Modifier.height(24.dp)); Text("Demo only — no real payments or egg earnings", color = Cream.copy(alpha = .65f), fontSize = 11.sp)
    }
}

@Composable
fun AuthScreen(title: String, phone: String, onPhone: (String) -> Unit, password: String, onPassword: (String) -> Unit, submit: () -> Unit, signup: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.Center) {
        BrandHeader(); Spacer(Modifier.height(30.dp)); Text(title, color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp)); InputField("Mobile number", phone, onPhone); InputField("Password", password, onPassword, true)
        Spacer(Modifier.height(18.dp)); GoldButton("LOGIN", submit); TextButton(onClick = signup) { Text("New user? Sign up", color = Cream) }
    }
}

@Composable
fun SignupScreen(name: String, onName: (String) -> Unit, phone: String, onPhone: (String) -> Unit, password: String, onPassword: (String) -> Unit, submit: () -> Unit, login: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.Center) {
        BrandHeader(); Spacer(Modifier.height(25.dp)); Text("CREATE ACCOUNT", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        InputField("Full name", name, onName); InputField("Mobile number", phone, onPhone); InputField("Create password", password, onPassword, true)
        Spacer(Modifier.height(16.dp)); GoldButton("CONTINUE TO OTP (DEMO)", submit); TextButton(onClick = login) { Text("Already registered? Login", color = Cream) }
    }
}

@Composable
fun OtpScreen(done: () -> Unit) {
    var otp by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        BrandHeader(); Spacer(Modifier.height(28.dp)); Text("MOBILE VERIFICATION", color = Gold, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text("Demo OTP: enter any 4 digits", color = Cream); InputField("4-digit OTP", otp, { otp = it })
        GoldButton("VERIFY (DEMO)", done)
    }
}

@Composable
fun HomeScreen(logout: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Cream).verticalScroll(rememberScrollState()).padding(18.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column { Text("👑 GOLDEN EGG KING", color = Forest, fontWeight = FontWeight.Black, fontSize = 20.sp); Text("Royal dashboard", color = Green) }
            TextButton(onClick = logout) { Text("Logout", color = Green) }
        }
        Spacer(Modifier.height(18.dp)); Card(colors = CardDefaults.cardColors(containerColor = Forest), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.fillMaxWidth().padding(20.dp)) { Text("WELCOME, KING!", color = Gold, fontWeight = FontWeight.Bold); Text("Your farm overview", color = Cream); Spacer(Modifier.height(12.dp)); Text("0 Eggs today", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold); Text("Demo balance: Rs. 0", color = Gold) }
        }
        Spacer(Modifier.height(20.dp)); Text("CHICKEN PACKAGES", color = Forest, fontSize = 19.sp, fontWeight = FontWeight.Black)
        listOf("Starter • 1 Hen", "Bronze • 5 Hens", "Silver • 10 Hens", "Gold • 25 Hens", "Royal • 50 Hens").forEach { PackageCard(it) }
        Spacer(Modifier.height(12.dp)); Text("MY ACCOUNT", color = Forest, fontSize = 19.sp, fontWeight = FontWeight.Black)
        listOf("Wallet & transactions", "Daily egg records", "Referral rewards", "Profile & settings").forEach { label -> Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) { Text(label, Modifier.padding(16.dp), color = Forest, fontWeight = FontWeight.SemiBold) } }
        Text("Demo interface only. Package prices, rewards and withdrawals are not active.", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(top = 14.dp))
    }
}

@Composable
fun PackageCard(label: String) {
    Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = Forest), shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column { Text("🐔 $label", color = Gold, fontWeight = FontWeight.Bold); Text("Package details", color = Cream.copy(alpha = .8f), fontSize = 12.sp) }
            Text("VIEW", color = Gold, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun InputField(label: String, value: String, onValue: (String) -> Unit, secret: Boolean = false) {
    OutlinedTextField(value, onValue, Modifier.fillMaxWidth().padding(vertical = 6.dp), label = { Text(label) }, singleLine = true, visualTransformation = if (secret) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None, colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Gold, unfocusedBorderColor = Cream, focusedLabelColor = Gold, unfocusedLabelColor = Cream))
}

@Composable
fun GoldButton(label: String, onClick: () -> Unit) {
    Button(onClick, Modifier.fillMaxWidth().height(52.dp), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Forest), shape = RoundedCornerShape(14.dp)) { Text(label, fontWeight = FontWeight.Black) }
}

@Composable
fun OutlineButton(label: String, onClick: () -> Unit) {
    OutlinedButton(onClick, Modifier.fillMaxWidth().height(52.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)) { Text(label, fontWeight = FontWeight.Bold) }
}
